from rest_framework.permissions import BasePermission


class IncidentPermission(BasePermission):
    """
    Gestion des permissions selon le rôle de l'utilisateur.
    """

    def has_permission(self, request, view):
        # L'utilisateur doit être connecté
        if not request.user or not request.user.is_authenticated:
            return False

        # RESPONSABLE : accès à toutes les opérations
        if request.user.role == 'RESPONSABLE':
            return True

        # DEMANDEUR : peut consulter et créer
        if request.user.role == 'DEMANDEUR':
            return request.method in [
                'GET',
                'HEAD',
                'OPTIONS',
                'POST',
                'PUT',
                'PATCH'
            ]

        # TECHNICIEN : peut uniquement consulter
        if request.user.role == 'TECHNICIEN':
            return request.method in [
                'GET',
                'HEAD',
                'OPTIONS',
                'PUT',
                'PATCH'
            ]

        return False

    def has_object_permission(self, request, view, obj):
        user = request.user

        # RESPONSABLE : accès à tous les incidents
        if user.role == 'RESPONSABLE':
            return True

        # DEMANDEUR : uniquement ses propres incidents
        if user.role == 'DEMANDEUR':
            if request.method in ['GET', 'HEAD', 'OPTIONS']:
                return obj.demandeur == user

            if request.method in ['PUT', 'PATCH']:
                return obj.demandeur == user

            return False

        # TECHNICIEN : uniquement les incidents qui lui sont affectés
        if user.role == 'TECHNICIEN':
            if request.method in [
                'GET',
                'HEAD',
                'OPTIONS',
                'PUT',
                'PATCH'
            ]:
                return obj.technicien == user

            return False

        return False
class CategoriePermission(BasePermission):
    """
    Gestion des permissions pour les catégories.
    """

    def has_permission(self, request, view):

        # L'utilisateur doit être authentifié
        if not request.user or not request.user.is_authenticated:
            return False

        # Tous les utilisateurs authentifiés peuvent consulter
        if request.method in ['GET', 'HEAD', 'OPTIONS']:
            return True

        # Seul le responsable peut créer, modifier ou supprimer
        return request.user.role == 'RESPONSABLE'