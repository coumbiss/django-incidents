from rest_framework import viewsets

from .models import Incident, Categorie
from .serializers import IncidentSerializer, CategorieSerializer
from .permissions import IncidentPermission, CategoriePermission



class IncidentViewSet(viewsets.ModelViewSet):
    serializer_class = IncidentSerializer
    permission_classes = [IncidentPermission]

    def get_queryset(self):
        user = self.request.user

        # Responsable : voit tous les incidents
        if user.role == 'RESPONSABLE':
            queryset = Incident.objects.all()

        # Technicien : voit les incidents non affectés ou qui lui sont affectés
        elif user.role == 'TECHNICIEN':
            queryset = Incident.objects.filter(
                technicien=user
            ) | Incident.objects.filter(
                technicien__isnull=True
            )

        # Demandeur : voit uniquement ses incidents
        else:
            queryset = Incident.objects.filter(
                demandeur=user
            )

        # Filtre par statut
        statut = self.request.query_params.get('statut')
        if statut:
            queryset = queryset.filter(statut=statut)

        # Filtre par priorité
        priorite = self.request.query_params.get('priorite')
        if priorite:
            queryset = queryset.filter(priorite=priorite)

        # Filtre par catégorie
        categorie = self.request.query_params.get('categorie')
        if categorie:
            queryset = queryset.filter(categorie=categorie)

        return queryset


class CategorieViewSet(viewsets.ModelViewSet):
    queryset = Categorie.objects.all()
    serializer_class = CategorieSerializer
    permission_classes = [CategoriePermission]