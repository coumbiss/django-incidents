from rest_framework.routers import DefaultRouter

from .views import IncidentViewSet, CategorieViewSet


router = DefaultRouter()

router.register(
    r'incidents',
    IncidentViewSet,
    basename='incident'
)

router.register(
    r'categories',
    CategorieViewSet,
    basename='categorie'
)

urlpatterns = router.urls